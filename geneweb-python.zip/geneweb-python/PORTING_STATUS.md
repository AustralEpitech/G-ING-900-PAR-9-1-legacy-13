# Porting Status: GeneWeb (OCaml) ➜ geneweb-python

Legend: [ ] TODO | [~] In Progress | [x] Done

## Commands (bin/)
- [x] gwd (web daemon) — HTTP REST API with search and filtering
- [ ] gwu (utilities)
- [x] gwb2ged (export) — GEDCOM exporter with full family linkage
- [x] ged2gwb (import) — GEDCOM importer with family linkage
- [x] check — Data consistency validation (orphans, dates, duplicates, broken links)
- [ ] gwdiff (diff)
- [ ] gwexport (export variants)
- [ ] gwc (console)
- [ ] setup/* (setup tools)

## Core domains (lib/)
- [x] Individuals / Families / Events — Full domain model with relationships
- [ ] Config parsing
- [ ] History & merges
- [x] Check & fixbase — Basic consistency checks implemented
- [ ] DAG & views
- [ ] Images & media

## Observability / Docs
- [x] Scaffolding
- [x] CLI parity reference
- [x] Behavior tests (8 tests covering export, import, daemon, validation)

## Test Coverage Summary
```
test_check.py:            3 tests (orphans, invalid dates, duplicates)
test_ged2gwb.py:          2 tests (import, roundtrip)
test_gwb2ged.py:          2 tests (minimal export, family links)
test_gwd.py:              1 test  (HTTP daemon endpoints)
---
Total:                    8 tests passing
```

Notes
- We will port feature-by-feature, keeping behavior parity via tests.
- Each item links to tests that assert signatures/outputs once created.