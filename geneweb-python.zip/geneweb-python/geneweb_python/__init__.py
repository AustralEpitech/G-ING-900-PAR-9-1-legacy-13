"""geneweb_python: Python reimplementation scaffold for GeneWeb.

This package will progressively reach parity with the OCaml GeneWeb project.
"""

__all__ = ["app"]