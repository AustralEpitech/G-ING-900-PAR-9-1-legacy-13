# geneweb-python

A Python reimplementation scaffold of the GeneWeb OCaml project.

This folder contains the structure, CLI entry points, and a porting plan to achieve behavior parity with the original OCaml GeneWeb located in `geneweb/`.

IMPORTANT
- This is phase 1: scaffolding + minimal wiring. Full feature parity requires incremental ports of each OCaml module and command.
- We will avoid copying OCaml source code directly to respect licensing; instead we reproduce behavior with new Python code and tests.

## Goals
- Provide a Python package `geneweb_python` that mirrors the concepts and commands from OCaml GeneWeb (gwd, gwu, gwb2ged, gwc, etc.).
- Incrementally port core domain (individuals, families, events) and commands.
- Maintain behavior parity via tests and fixtures derived from public behavior (CLI options, outputs, files produced).

## Structure
```
 geneweb-python/
 ├─ README.md                    # This file
 ├─ PORTING_STATUS.md            # Live checklist of porting progress
 ├─ pyproject.toml               # Minimal packaging to run module entry points
 ├─ bin/
 │   ├─ gwd.py                   # Web daemon placeholder (to be implemented)
 │   ├─ gwu.py                   # Utility placeholder (to be implemented)
 │   ├─ gwb2ged.py               # Converter placeholder (to be implemented)
 │   └─ gwc.py                   # Console placeholder (to be implemented)
 └─ geneweb_python/
     ├─ __init__.py
     └─ app/
         └─ cli.py              # Central CLI router (incremental parity)
```

## Quick start

```bash
python -m geneweb_python.app.cli --help
```

```bash
python -m geneweb_python.app.cli gwd --help
```

Note: At this stage, commands are placeholders that describe next steps and expected behavior. We will replace them with real implementations iteratively.

### Working commands

#### gwb2ged (GEDCOM export)

Export a Database pickle to GEDCOM with family links (HUSB/WIFE/CHIL and FAMS/FAMC):

```bash
python geneweb-cli.py gwb2ged --db-file database.pkl -o output.ged
```

Or print to stdout:

```bash
python geneweb-cli.py gwb2ged --db-file database.pkl -o -
```

#### ged2gwb (GEDCOM import)

Import a GEDCOM file into a Database pickle:

```bash
python geneweb-cli.py ged2gwb input.ged --db-file database.pkl
```

These commands support bidirectional conversion and preserve family structures (spouses, children, parents).

#### gwd (HTTP daemon)

Start a REST API server to query genealogical data:

```bash
python geneweb-cli.py gwd --db-file database.pkl --host 127.0.0.1 --port 2317
```

Endpoints:
- `GET /persons` - List all persons (optional filter: `?surname=<name>`)
- `GET /persons/<id>` - Get a person by ID
- `GET /families` - List all families
- `GET /families/<id>` - Get a family by ID
- `GET /search?q=<query>` - Search persons by name (first_name or surname substring match)

Example:
```bash
curl http://127.0.0.1:2317/persons
curl http://127.0.0.1:2317/search?q=Smith
```

#### check (data validation)

Run consistency checks on the database:

```bash
python geneweb-cli.py check --db-file database.pkl
```

This validates:
- Orphan persons (not linked to any family)
- Invalid dates (death before birth)
- Duplicate names
- Broken family links

## Porting strategy
1. Map OCaml modules in `geneweb/lib` to Python subpackages and data models.
2. Start with read-only/format tasks (parsers, exporters), then stateful services (daemon), then advanced features.
3. For each command (gwd, gwu, gwb2ged, gwc, etc.):
   - Mirror flags and outputs.
   - Add tests verifying the same observable behavior.
   - Implement incrementally behind a feature flag until complete.

## Development
- Python version: 3.11+
- Dependency management: Add packages to this subproject as needed in `pyproject.toml`.

## License
The Python code here is newly implemented to respect the original project's license. It aims to replicate behavior without copying source code.